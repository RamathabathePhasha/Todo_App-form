import React from 'react';
import Todos from './components/todos';


function App() {
  return (

    <Todos/>

  )
}

export default App;