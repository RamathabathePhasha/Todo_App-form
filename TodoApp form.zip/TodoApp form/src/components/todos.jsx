import React, { useState } from 'react';
import './todos.css';

function Todos() {
  // State for managing the todo list
  const [todos, setTodos] = useState([]);
  // State for managing the input field for todo name
  const [todoName, setTodoName] = useState('');
  // State for managing the input field for todo description
  const [description, setDescription] = useState('');

  // Function to add a new todo to the list
  const addTodo = (event) => {
    event.preventDefault();
    // Creating a new todo object using the input values
    const newTodo = { todoName, description, complete: false };
    // Updating the todo list with the new todo
    setTodos([...todos, newTodo]);
    // Clearing the input fields after adding the todo
    setTodoName('');
    setDescription('');
  };

  // Function to delete a todo from the list
  const deleteTodo = (index) => {
    // Filtering out the todo to be deleted from the list
    const updatedTodos = todos.filter((_, i) => i !== index);
    // Updating the todo list without the deleted todo
    setTodos(updatedTodos);
  };

  // Function to mark a todo as done or undone
  const markAsDone = (index) => {
    // Toggling the completion status of the selected todo
    const updatedTodos = todos.map((todo, i) =>
      i === index ? { ...todo, complete: !todo.complete } : todo
    );
    // Updating the todo list with the modified todo
    setTodos(updatedTodos);
  };

  // Function to edit an existing todo
  const editTodo = (index, newTodoName, newDescription) => {
    // Updating the todo with new name and description
    const updatedTodos = todos.map((todo, i) =>
      i === index ? { ...todo, todoName: newTodoName, description: newDescription } : todo
    );
    // Updating the todo list with the edited todo
    setTodos(updatedTodos);
  };

  return (
    <div>
      <h1>Todos</h1>
      <form onSubmit={addTodo}>
        <label htmlFor="todoName">Todo Name:</label>
        <input
          type="text"
          id="todoName"
          value={todoName}
          onChange={(e) => setTodoName(e.target.value)}
        />
        <br />
        <label htmlFor="description">Description:</label>
        <textarea
          id="description"
          rows="4"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        ></textarea>
        <br />
        <button type="submit">Add Todo</button>
      </form>

      <ul>
        {/* Mapping over the todos to display each todo item */}
        {todos.map((todo, index) => (
          <li key={index}>
            {/* Applying strikethrough style if todo is marked as complete */}
            <span style={{ textDecoration: todo.complete ? 'line-through' : 'none' }}>
              {todo.todoName} - {todo.description}
            </span>
            {/* Button to delete the todo */}
            <button onClick={() => deleteTodo(index)}>Delete</button>
            {/* Button to mark the todo as done or undone */}
            <button onClick={() => markAsDone(index)}>
              {todo.complete ? 'Mark as Undone' : 'Mark as Done'}
            </button>
            {/* Button to edit the todo */}
            <button
              onClick={() => {
                // Prompting user for new todo name and description
                const newTodoName = prompt('Enter new todo name:', todo.todoName);
                const newDescription = prompt('Enter new description:', todo.description);
                // Editing the todo with the new values
                editTodo(index, newTodoName, newDescription);
              }}
            >
              Edit
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Todos;
